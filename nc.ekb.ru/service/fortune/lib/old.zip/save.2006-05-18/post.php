<?
global $CFG;

function NormStr($S)
{
 return join("\n", array_map(rtrim, preg_split('/(\\r\\n?)|\\n/', rtrim($S))));
}

$S=NormStr($_REQUEST['o']);
$CFG->params->n=(int)$_REQUEST['n'];

odbc_autocommit($CFG->odbc, false);

switch($_REQUEST['x'])
{
 case 'new':
  $SX='��������';
  $doIt=1;
  $x=odbc_prepare($CFG->odbc, "Select 1+Max(Origins.N) N1, 1+Max(Hist.oId) N2 From Origins, Hist");
  odbc_execute($x);
  $r=odbc_fetch_object($x);
  $CFG->params->n=max($r->N1, $r->N2);
  $x=odbc_prepare($CFG->odbc, "Insert Into Origins(N, S) Values(?, ?)");
  odbc_execute($x, Array($CFG->params->n, ".$S"));
  break;
 case 'delete':
  $SX='��������';
  $doIt=-1;
  $x=odbc_prepare($CFG->odbc, "Delete From Origins Where N=?");
  odbc_execute($x, Array($CFG->params->n));
  break;
 default:
  $SX='�����������';
  $x=odbc_prepare($CFG->odbc, "Select * From Origins Where N=?");
  odbc_execute($x, Array($CFG->params->n));
  $r=odbc_fetch_object($x);
  if($S==$r->S) break;
  $doIt=1;
  $x=odbc_prepare($CFG->odbc, "Update Origins Set S=? Where N=?");
  odbc_execute($x, Array("=$S", $CFG->params->n));
}

if($doIt>0):
 $x=odbc_prepare($CFG->odbc, "Update Origins Set S=substr(S, 2, length(S)) Where N=?");
 odbc_execute($x, Array($CFG->params->n));
endif;

$S=NormStr($_REQUEST['Note']);
if($S or $doIt):
 if(!$S) $S=$SX;
 $IP=$_SERVER["HTTP_X_FORWARDED_FOR"];
 if($IP) $IP=" ".$IP;
 $x=odbc_prepare($CFG->odbc, "Insert Into Hist(oId, TimeStamp, Note, user, IP) Values(?, strftime('%s', 'now'), ?, ?, ?)");
 odbc_execute($x, Array($CFG->params->n, "=$S", $CFG->u, $_SERVER['REMOTE_ADDR'].$IP));
 odbc_exec($CFG->odbc, "Update Hist Set Note=substr(Note, 2, length(Note)) Where N=last_insert_rowid()");
endif;

odbc_commit($CFG->odbc);

header('Location: ./'.hRef('n', $doIt>=0?$CFG->params->n:null));


?>

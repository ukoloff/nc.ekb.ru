<?
exit;
require("autoload.php");
odbc_autocommit($CFG->odbc, false);
$x=odbc_prepare($CFG->odbc, "Insert Into Origins(S) Values(?)");
foreach(file("../../fortune/origins.txt") as $s):
 odbc_execute($x, Array(preg_replace('/\\\\n/', "\n", rtrim($s))));
endforeach;
odbc_commit($CFG->odbc);
?>
